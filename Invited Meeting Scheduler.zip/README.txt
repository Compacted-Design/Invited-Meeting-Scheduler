Please don't edit anything in the data folder except for the files in the schedule folder.
Additionally, don't move any of the files in this folder out of the folder.

To Launch the Application, click on the executable, InvitedMeetingScheduler.exe